run npm install, then npm start
