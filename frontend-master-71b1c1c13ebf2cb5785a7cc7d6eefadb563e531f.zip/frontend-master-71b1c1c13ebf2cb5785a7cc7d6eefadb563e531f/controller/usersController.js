var multer = require('multer');
var upload = multer({dest: './uploads'});
var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var User = require('../models/user');
function get(request, response, next){
    response.render('index', { title: 'Members' });
}
function registerGet(request, response, next){
    response.render('register',{title:'Register'});
}
function registerPost(request, response, next){
    var name = request.body.name;
    var email = request.body.email;
    var username = request.body.username;
    var password = request.body.password;
    var password2 = request.body.password2;

    if(request.file){
       console.log('Uploading File...');
       var profileimage = request.file.filename;
    } else {
       console.log('No File Uploaded...');
       var profileimage = 'noimage.jpg';
    }

    // Form Validator
    request.checkBody('name','Name field is required').notEmpty();
    request.checkBody('email','Email field is required').notEmpty();
    request.checkBody('email','Email is not valid').isEmail();
    request.checkBody('username','Username field is required').notEmpty();
    request.checkBody('password','Password field is required').notEmpty();
    request.checkBody('password2','Passwords do not match').equals(request.body.password);

    var errors = request.validationErrors();
    // Check Errors

    if(errors)
    {
       response.render('register', {
           errors: errors
       });
    }
    else
    {
       var newUser = new User({
        name: name,
        email: email,
        username: username,
        password: password,
        profileimage: profileimage
      });

      User.createUser(newUser, function(err, user){
        if(err) throw err;
        console.log(user);
      });

      request.flash('success', 'You are now registered and can login');

      response.location('/');
      response.redirect('/');
    }
}
function loginGet(request, response, next){
    response.render('login', {title:'Login'});
}
function loginPost(request, response, next){
     request.flash('success', 'You are now logged in');
     response.redirect('/');
}
function logoutGet(request, response, next){
    request.logout();
    // req.flash() to give output to screen
    request.flash('success', 'You are now logged out');
    response.redirect('/users/login');
}
module.exports = {
    get : get,
    registerGet : registerGet,
    registerPost : registerPost,
    loginGet : loginGet,
    loginPost : loginPost,
    logoutGet : logoutGet
}
