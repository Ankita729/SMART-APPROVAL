function get(request, response, next){
    response.render('index', { title: 'Members' });
}
function ensureAuthenticated(request, response, next){
	if(request.isAuthenticated()){
		return next();
	}
	response.redirect('/users/login');
}
module.exports = {
    get : get,
    ensureAuthenticated : ensureAuthenticated
}
